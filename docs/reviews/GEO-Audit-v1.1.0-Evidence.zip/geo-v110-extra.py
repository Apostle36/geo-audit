import sys,os,json,subprocess,runpy,shutil
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
sys.dont_write_bytecode=True
R=Path("/home/leo/apps/geo-audit-repo"); T=Path("/tmp/geo-v110-audit-ua0_o0n0")
env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1"}
def render(name):
 r=subprocess.run([sys.executable,str(R/"scripts/geo-audit-pdf.py"),str(T/"short.md"),str(T/(name+".pdf"))],env=env,capture_output=True,text=True,timeout=40)
 return {"name":name,"exit":r.returncode}
with ThreadPoolExecutor(max_workers=2) as pool:
 result=list(pool.map(render,["concurrent-a","concurrent-b"]))
p=T/"actual-collision.md";shutil.copy2(T/"short.md",p)
r=subprocess.run([sys.executable,str(R/"scripts/geo-audit-pdf.py"),str(p),str(p)],env=env,capture_output=True,text=True,timeout=40)
result.append({"test":"actual_input_output_collision","exit":r.returncode,"header":p.read_bytes()[:8].decode(errors="replace")})
for args,name in [([str(R/"scripts/score.py"),str(T/"invalid.json")],"malformed_json")]:
 (T/"invalid.json").write_text("{broken")
 r=subprocess.run([sys.executable]+args,env=env,capture_output=True,text=True)
 result.append({"test":name,"exit":r.returncode,"error":r.stderr[-300:]})
r=subprocess.run([sys.executable,"-S",str(R/"scripts/geo-audit-pdf.py"),"--help"],env=env,capture_output=True,text=True)
result.append({"test":"missing_dependencies_help","exit":r.returncode,"error":r.stderr[-300:]})
# Read-only source snapshot checks after tests.
result.append({"test":"repo_status","output":subprocess.check_output(["git","status","--short"],cwd=R,text=True)})
(T/"extra-results.json").write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))

