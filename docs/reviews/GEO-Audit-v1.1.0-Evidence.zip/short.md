**Audit Date:** 2026-09-10
**URL:** https://example.com
**Business Type:** Synthetic
**Pages Analyzed:** 1
**Overall GEO Score: 50/100**
## Executive Summary
Résumé: доказателства. [Source](https://example.com)
## Findings
> Quoted evidence

```html
<div>x & y</div>
```
