import sys
sys.dont_write_bytecode=True
import runpy,json,tempfile,shutil,subprocess,os
from pathlib import Path
from unittest.mock import patch
R=Path("/home/leo/apps/geo-audit-repo")
T=Path(tempfile.mkdtemp(prefix="geo-v110-audit-"))
pdf=runpy.run_path(str(R/"scripts/geo-audit-pdf.py")); ev=runpy.run_path(str(R/"scripts/evidence.py")); sc=runpy.run_path(str(R/"scripts/score.py"))
results=[]
def check(name,call):
 try: results.append({"test":name,"result":call()})
 except BaseException as e: results.append({"test":name,"exception":type(e).__name__,"message":str(e)[:250]})
def full(**kw):
 d={k:[{"id":"one","status":"assessed","value":80,"evidence_ids":["p1"]}] for k in sc["WEIGHTS"]}
 for c in d.values():c[0].update(kw)
 return d
cases={
"multiple_upper":'<SCRIPT TYPE=\'application/ld+json\'>{"@type": "Organization"}</SCRIPT><script type = "application/ld+json">[{"@type":["WebSite","Thing"]}]</script>',
"graph":'<script type="application/ld+json">{"@graph":[{"@id":"#x","@type":"Person"},{"@id":"#x"}]}</script>',
"malformed":'<script type="application/ld+json">{invalid}</script>',
"unclosed":'<script type="application/ld+json">{"@type":"Person"}',
"duplicate_json_keys":'<script type="application/ld+json">{"name":"First","name":"Second"}</script>',
"conflicting_entities":'<script type="application/ld+json">[{"@id":"#x","name":"A"},{"@id":"#x","name":"B"}]</script>',
"nonstandard_json":'<script type="application/ld+json">{"value":NaN}</script>',
"duplicate_titles":"<title>Alpha &amp; β</title><title>Other</title>",
"duplicate_meta":'<meta name="description" content="a"><meta name="description" content="b"><link rel="canonical" href="/a"><link rel="canonical" href="/b">',
"boolean_meta":"<meta name>","boolean_link":"<link rel>","boolean_script":"<script type></script>",
"microdata":'<div itemscope itemtype="https://schema.org/Organization"><span itemprop="name">X</span></div>',
"rdfa":'<div vocab="https://schema.org/" typeof="Organization"><span property="name">X</span></div>',
"empty":"","js_shell":'<div id="root"></div><script src="app.js"></script>',
"error":"<title>Not found</title><p>404: missing</p>","challenge":"<title>Just a moment</title><p>Verify you are human</p>"}
for n,h in cases.items():check("evidence/"+n,lambda h=h:ev["extract"](h))
for v in ["90",True,-1,101,float("nan"),float("inf"),33.333]:check("score/value_"+str(v),lambda v=v:sc["calculate"](full(value=v)))
cases={"valid":full(),"missing":{},"empty_category":dict(full(),schema=[]),"unknown":dict(full(),schema=[{"id":"one","status":"unknown"}]),"all_na":dict(full(),schema=[{"id":"one","status":"not_applicable","reason":"none"}]),"na_no_reason":dict(full(),schema=[{"id":"one","status":"not_applicable"}]),"missing_evidence":full(evidence_ids=[]),"string_evidence":full(evidence_ids="fiction"),"null_evidence_item":full(evidence_ids=[None]),"fake_evidence":full(evidence_ids=["does-not-exist"]),"unexpected_fields":full(fabricated=True),"bad_status":full(status="present"),"no_status":dict(full(),schema=[{"id":"one"}]),"list_input":[],"null_input":None,"null_category":dict(full(),schema=None),"string_category":dict(full(),schema="x"),"duplicate_ids":dict(full(),schema=full()["schema"]*2),"omitted_hard_criteria":full(value=100),"na_hard_criteria":{k:v+[{"id":"hard","status":"not_applicable","reason":"skip"}] for k,v in full(value=100).items()}}
for n,d in cases.items():check("score/"+n,lambda d=d:sc["calculate"](d))
base="**Overall GEO Score: 50/100**"; fence=chr(96)*3
cases={"integer":base,"decimal":"**Overall GEO Score: 72.5/100**","missing":"No score","invalid":"**Overall GEO Score: 999/100**","unassessed":"**Overall GEO Score: Not assessed**","contradictory":base+"\n**Overall GEO Score: 90/100**","contradictory_na":"**Overall GEO Score: Not assessed**\n"+base,"fenced":fence+"md\n**Overall GEO Score: 99/100**\n"+fence+"\n"+base,"tilde":"~~~md\n**Overall GEO Score: 99/100**\n~~~~\n"+base,"unclosed_fence":fence+"md\n**Overall GEO Score: 99/100**","fenced_heading":base+"\n## Findings\n"+fence+"md\n## Example\n"+fence+"\nTail","late_metadata":"\n"*21+"**URL:** https://example.com\n"+base,"invalid_metadata":"**URL:** not-a-url\n**Audit Date:** yesterday\n**Pages Analyzed:** -5\n"+base,"no_sections":base+"\nIMPORTANT CONCLUSION","intro_before_sections":base+"\nIMPORTANT CONCLUSION\n## Findings\nDetails"}
for n,t in cases.items():check("pdf/"+n,lambda t=t:pdf["parse_report"](t))
cases={"code":fence+"html\n<div>x & y</div>\n"+fence,"quote":"> quoted evidence","checklist":"- [ ] Task\n- [x] Done","nested":"- Parent\n    - Child","raw_html":"<script>alert(1)</script>","js_link":"[x](javascript:alert)","file_link":"[x](file:///etc/passwd)","attribute":'[x](https://example.com/" onmouseover="alert)',"invalid_ipv6":"[x](https://[invalid)","image":"![Critical evidence](https://example.com/evidence.png)"}
for n,t in cases.items():check("html/"+n,lambda t=t:pdf["md_to_html"](t))
for dest in [Path("/home/leo/.agents/skills/geo-audit"),Path("/home/leo/.claude/skills/geo-audit")]:
 mapping={Path("SKILL.md"):R/".claude/skills/geo-audit/SKILL.md"}
 for folder,src in [("agents",R/".claude/agents"),("scripts",R/"scripts")]:mapping.update({Path(folder)/p.name:p for p in src.iterdir() if p.is_file()})
 check("installed/"+str(dest),lambda d=dest,m=mapping:{"matches":all((d/k).exists() and (d/k).read_bytes()==v.read_bytes() for k,v in m.items()),"files":len(m),"extras":[str(p.relative_to(d)) for p in d.rglob("*") if p.is_file() and ".backups" not in p.parts and "__pycache__" not in p.parts and p.relative_to(d) not in m],"backups":len(list((d/".backups").glob("*/SKILL.md")))})
inst=runpy.run_path(str(R/"scripts/install.py"))["install"];D=T/"skills with spaces"
check("install/fresh",lambda:inst(D));dest=D/"geo-audit"
(dest/"custom.txt").write_text("custom");(dest/"scripts/stale.py").write_text("old");(dest/"SKILL.md").write_text("CUSTOMIZED")
check("install/reinstall",lambda:inst(D))
check("install/reinstall_state",lambda:{"custom_retained":(dest/"custom.txt").exists(),"stale_retained":(dest/"scripts/stale.py").exists(),"backup_customized":any(p.read_text()=="CUSTOMIZED" for p in dest.glob(".backups/*/SKILL.md"))})
check("install/source_rejected",lambda:inst(R/".claude/skills"))
check("install/bundled_reinstaller",lambda:runpy.run_path(str(dest/"scripts/install.py"))["install"](T/"second"))
source=T/"isolated repo";shutil.copytree(R,source,ignore=shutil.ignore_patterns(".git","__pycache__","GEO-AUDIT-REPORT.*"))
(source/"scripts").rename(source/"scripts-held")
check("install/missing_scripts",lambda:runpy.run_path(str(source/"scripts-held/install.py"))["install"](T/"partial"))
check("install/partial_state",lambda:{"skill_exists":(T/"partial/geo-audit/SKILL.md").exists(),"scripts_exist":(T/"partial/geo-audit/scripts").exists()})
f=T/"collision.md";f.write_text(base);g=pdf["main"].__globals__;seen=[]
def collision():
 with patch.dict(g,render_to_pdf=lambda path:b"%PDF-STUB"),patch.object(sys,"argv",["pdf",str(f),str(f)]):pdf["main"]()
 return f.read_bytes().decode()
check("pdf/input_output_collision_mocked_browser",collision)
def fail(path):seen.append(path);raise RuntimeError("synthetic browser failure")
def failure_cleanup():
 f=T/"failed.md";f.write_text(base)
 with patch.dict(g,render_to_pdf=fail),patch.object(sys,"argv",["pdf",str(f)]):
  try:pdf["main"]()
  except RuntimeError:pass
 return {"temp_cleaned":not seen[-1].exists(),"input_preserved":f.read_text()==base}
check("pdf/failure_cleanup_mocked_browser",failure_cleanup)
short="**Audit Date:** 2026-09-10\n**URL:** https://example.com\n**Business Type:** Synthetic\n**Pages Analyzed:** 1\n"+base+"\n## Executive Summary\nRésumé: доказателства. [Source](https://example.com)\n## Findings\n> Quoted evidence\n\n"+fence+"html\n<div>x & y</div>\n"+fence+"\n"
long=short+"\n## Evidence table\n| URL | Finding |\n|---|---|\n"+"".join(f"| https://example.com/{'long'*40}/{i} | Row {i} meaningful evidence |\n" for i in range(100))+"\n## Actions\n- [ ] Fix\n- [x] Verified\n"
for n,t in [("short",short),("long",long)]:
 p=T/(n+".md");p.write_text(t)
 r=subprocess.run([sys.executable,str(R/"scripts/geo-audit-pdf.py"),str(p),str(T/(n+".pdf"))],capture_output=True,text=True,timeout=45,env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1"})
 (T/(n+"-render.log")).write_text(r.stdout+r.stderr)
 check("render/"+n,lambda r=r:{"exit":r.returncode,"tail":r.stderr[-800:]})
check("install/helper_outside_repo",lambda:subprocess.run([sys.executable,str(dest/"scripts/geo-audit-pdf.py"),"--help"],cwd="/tmp",capture_output=True,text=True).returncode)
(T/"results.json").write_text(json.dumps(results,indent=2,ensure_ascii=False))
print("AUDIT_DIR",T)
for row in results:print(json.dumps(row,ensure_ascii=False))

